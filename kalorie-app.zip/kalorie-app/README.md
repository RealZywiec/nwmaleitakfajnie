# Skaner Kalorii AI

Aplikacja webowa do szacowania wartości odżywczych z zdjęć jedzenia, zasilana przez Claude AI.

## Struktura projektu

```
kalorie-app/
├── api/
│   └── analyze.js      ← Serverless function (proxy do Anthropic API)
├── public/
│   └── index.html      ← Frontend aplikacji
├── vercel.json         ← Konfiguracja Vercel
└── .gitignore
```

## Jak wdrożyć na Vercel

### 1. Wrzuć na GitHub
```bash
git init
git add .
git commit -m "init"
git remote add origin https://github.com/TWOJA-NAZWA/kalorie-app.git
git push -u origin main
```

### 2. Połącz z Vercel
1. Wejdź na vercel.com i zaloguj się przez GitHub
2. Kliknij "New Project" i zaimportuj repozytorium
3. Framework Preset: **Other**
4. Root Directory: pozostaw puste (główny folder)
5. Kliknij "Deploy"

### 3. Dodaj klucz API (WAŻNE)
1. W panelu Vercel → Twój projekt → Settings → Environment Variables
2. Dodaj nową zmienną:
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** `sk-ant-...` (Twój klucz z console.anthropic.com)
   - **Environment:** Production, Preview, Development (zaznacz wszystkie)
3. Kliknij Save, potem **Redeploy** projekt

### 4. Gotowe
Aplikacja działa pod adresem `https://nazwa-projektu.vercel.app`

## Bezpieczeństwo

- Klucz API jest **tylko** w zmiennych środowiskowych Vercel – nigdy w kodzie
- Frontend nigdy nie widzi klucza
- Serverless function (`/api/analyze`) jest proxy między frontendem a Anthropic API

## Jak uzyskać klucz API Anthropic

1. Wejdź na https://console.anthropic.com
2. Zarejestruj się / zaloguj
3. Settings → API Keys → Create Key
4. Skopiuj klucz (zaczyna się od `sk-ant-`)

Nowe konta Anthropic otrzymują darmowe kredyty startowe.
